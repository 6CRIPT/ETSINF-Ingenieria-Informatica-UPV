/***************************************************
Hecho por C�sar Mart�nez Chico
TERMINADO ENTREGAR
***************************************************/
#define PROYECTO "ISGI::Nave espacial by C�sar"

#include <iostream> 
#include <cmath> 
#include <gl\freeglut.h> 
#include <cstdlib> 
#include <ctime>   
#include <codebase.h>
#include <freeimage/FreeImage.h> 
#include <mciapi.h>


using namespace std;
using namespace cb;

static Sistema3d camara;
static Vec3 camara_pos_act;
static Vec3 altura_act;
static Vec3 objetivo;
static const int FPS = 60;
static float vel_act = 0;
static int ancho_de_ventana = 900;
static int altura_de_ventana = 900;
static int x_centro = ancho_de_ventana / 2;
static int y_centro = altura_de_ventana / 2;
static float z_global = 2;
static float cabina_se_vea_bool = 1;
static const int dim_suelo = 15;
const int numAsteroides = 24;
float posicionAsteroides[numAsteroides][3];
float velocidad_Asteroides[numAsteroides][3];
const int dim_Espacio = 200;
bool luces_activadas = false;
bool luz_roja_activada = false;
bool luces_antinieblas_activadas = false;

//musica
bool musica = false;
LPCWSTR u = L"open \"interestellar.mp3\" type mpegvideo alias mp3";
LPCWSTR i = L"play interestellar.mp3 repeat";
LPCWSTR o = L"pause interestellar.mp3";
LPCWSTR p = L"resume interestellar.mp3";

static float distancia_cabina_cara = 0;
static float alfa = 0;
static float alfa_aux = 0;
static float beta = -1.5;
static float direccion = 1; 
static float sigma = 0;
static float direccion2 = 1; 

float cont = 0;
static GLuint erre, nubes, rayas, estrellas, jupiter, cabina, asteroide, asteroide2, superficie, hangar;

void cargar_textura_hangar(){
	glGenTextures(1, &hangar);
	glBindTexture(GL_TEXTURE_2D, hangar);
	loadImageFile((char*)"hangar.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}
void cargar_textura_plataforma() {
	glGenTextures(1, &superficie);
	glBindTexture(GL_TEXTURE_2D, superficie);
	loadImageFile((char*)"plataforma_despegue.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}
void cargar_textura_estrellas() {
	glGenTextures(1, &estrellas);
	glBindTexture(GL_TEXTURE_2D, estrellas);
	loadImageFile((char*)"estrellas2.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}
void cargar_textura_cabina() {
	glGenTextures(1, &cabina);
	glBindTexture(GL_TEXTURE_2D, cabina);
	loadImageFile((char*)"cabina.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}
void cargar_textura_asteroide() {
	glGenTextures(1, &asteroide);
	glBindTexture(GL_TEXTURE_2D, asteroide);
	loadImageFile((char*)"textura_asteroides.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}
void cargar_textura_asteroide2() {
	glGenTextures(1, &asteroide2);
	glBindTexture(GL_TEXTURE_2D, asteroide2);
	loadImageFile((char*)"textura_asteroides2.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}
void cargar_textura_jupiter() {
	glGenTextures(1, &jupiter);
	glBindTexture(GL_TEXTURE_2D, jupiter);
	loadImageFile((char*)"jupiter.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}
void cargar_Texturas(){
	cargar_textura_asteroide();
	cargar_textura_asteroide2();
	cargar_textura_cabina();
	cargar_textura_estrellas();
	cargar_textura_jupiter();
	cargar_textura_plataforma();
	cargar_textura_hangar();
}
void bindear_texturas_fondo_estelar() {
	glBindTexture(GL_TEXTURE_2D, estrellas);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE); // PARA QUE LA LUZ NO LE AFECTE
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
}
void fondo_estelar_vector() {
	GLfloat vertice0[] = { -dim_Espacio, -dim_Espacio, -dim_Espacio };
	GLfloat vertice1[] = { dim_Espacio, -dim_Espacio, -dim_Espacio };
	GLfloat vertice2[] = { dim_Espacio,  dim_Espacio, -dim_Espacio };
	GLfloat vertice3[] = { -dim_Espacio,  dim_Espacio, -dim_Espacio };

	GLfloat vertice4[] = { -dim_Espacio, -dim_Espacio, dim_Espacio };
	GLfloat vertice5[] = { dim_Espacio, -dim_Espacio, dim_Espacio };
	GLfloat vertice6[] = { dim_Espacio,  dim_Espacio, dim_Espacio };
	GLfloat vertice7[] = { -dim_Espacio,  dim_Espacio, dim_Espacio };

	//caras cubo
	quadtex(vertice0, vertice1, vertice2, vertice3);  // frontal
	quadtex(vertice1, vertice5, vertice6, vertice2);  // lateral derecha
	quadtex(vertice4, vertice0, vertice3, vertice7);  // lateral izquierda
	quadtex(vertice5, vertice4, vertice7, vertice6);  // trasera
	quadtex(vertice3, vertice2, vertice6, vertice7);  // superior
	quadtex(vertice0, vertice4, vertice5, vertice1);  // inferior
}
void draw_fondo_estelar() {
	
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	bindear_texturas_fondo_estelar();
	fondo_estelar_vector();
	glPopAttrib();
}
void asteroide_vector(GLfloat lado) {
	
	GLfloat verticeA[] = { -lado + 3, -lado, -lado }; //A SUMO  3 PARA DEFORMAR
	GLfloat verticeB[] = { lado, -lado, -lado }; //B
	GLfloat verticeC[] = { lado,  lado, -lado };	//C
	GLfloat verticeD[] = { -lado,  lado, -lado }; // D
	GLfloat verticeE[] = { -lado, -lado, lado }; // E
	GLfloat verticeF[] = { lado +1, -lado, lado }; //F LO MISMO, DEFORMO LIGERAMENTE
	GLfloat verticeG[] = { lado,  lado, lado }; //G
	GLfloat verticeH[] = { -lado,  lado, lado }; //H 

	GLfloat Em[] = { 0.1,0.1,0.2,1.0 };
	GLfloat Am[] = { 0.2,0.2,0.2,1.0 };
	GLfloat Dm[] = { 0.5,0.7,0.6,1.0 };
	GLfloat Sm[] = { 0.8,0.8,0.8,1.0 };
	GLfloat s = 20.0;
	//materiales
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, Em);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, Am);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, Dm);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, Sm);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, s);
	// caras
	quadtex(verticeG, verticeF, verticeB, verticeC);  // Cara frontal
	quadtex(verticeH, verticeG, verticeC, verticeD);  // Cara lateral derecha
	quadtex(verticeE, verticeA, verticeB, verticeF);  // Cara lateral izquierda
	quadtex(verticeA, verticeE, verticeH, verticeD);  // Cara trasera
	quadtex(verticeH, verticeE, verticeF, verticeG);  // Cara superior
	quadtex(verticeA, verticeD, verticeC, verticeB);  // Cara inferior
}
void bindear_texturas_asteroide() {
	glBindTexture(GL_TEXTURE_2D, asteroide);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
}
void bindear_texturas_asteroide2() {
	glBindTexture(GL_TEXTURE_2D, asteroide2);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
}
void drawAsteroid(float size) {
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	GLfloat lado = size;  
	asteroide_vector(size);
	glPopAttrib();
}
void camara_ajustes() {
	camara_pos_act = camara.geto();
	objetivo = camara_pos_act - camara.getw();
	altura_act = camara.getv();
}
void draw_suelo() {
	glBindTexture(GL_TEXTURE_2D, superficie);
	GLfloat verticeA[] = { -dim_suelo, dim_suelo, 0 };
	GLfloat verticeB[] = { dim_suelo, dim_suelo, 0 };
	GLfloat verticeC[] = { dim_suelo, -dim_suelo, 0 };
	GLfloat verticeD[] = { -dim_suelo, -dim_suelo, 0 };
	GLfloat Em[] = { 0.1,0.1,0.2,1.0 };
	GLfloat Am[] = { 0.2,0.2,0.2,1.0 };
	GLfloat Dm[] = { 0.5,0.7,0.6,1.0 };
	GLfloat Sm[] = { 0.8,0.8,0.8,1.0 };
	GLfloat s = 20.0;
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, Em);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, Am);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, Dm);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, Sm);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, s);
	quadtex(verticeA, verticeD, verticeC, verticeB, 0, 1, 0, 1, 300, 300);
}
void bindear_hangar() {
	glBindTexture(GL_TEXTURE_2D, hangar);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}
void draw_hangar() {
	glBindTexture(GL_TEXTURE_2D, hangar);
	GLfloat verticeA[] = { 1,0,1 };
	GLfloat verticeB[] = { -1,0,1};
	GLfloat verticeC[] = { -1, -2, 0.5};
	GLfloat verticeD[] = { 1, -2, 0.5 };
	GLfloat verticeE[] = { -1, -2, 0.1 };
	GLfloat verticeF[] = { 1, -2, 0.1 };
	GLfloat verticeG[] = { 1, 0.75, 0.1 };
	GLfloat verticeH[] = { -1, 0.75, 0.1 };
	GLfloat Em[] = { 0.1,0.1,0.2,1.0 };
	GLfloat Am[] = { 0.2,0.2,0.2,1.0 };
	GLfloat Dm[] = { 0.5,0.7,0.6,1.0 };
	GLfloat Sm[] = { 0.8,0.8,0.8,1.0 };
	GLfloat s = 20.0;
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, Em);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, Am);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, Dm);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, Sm);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, s);
	glPushMatrix();
	glTranslatef(0,0.25,0); //levantarlo ligeramente del suelo para que no se bugge el suelo con la plataforma
	glScalef(4,4,4); //para hacerlo mas grande
	quadtex(verticeA, verticeB, verticeC, verticeD, 0, 1, 0, 1, 100, 100);
	quadtex(verticeC, verticeB, verticeH, verticeE, 0, 1, 0, 1, 100, 100);
	quadtex(verticeA, verticeD, verticeF, verticeG, 0, 1, 0, 1, 100, 100);
	quadtex(verticeD, verticeC, verticeE, verticeF, 0, 1, 0, 1, 100, 100);
	quadtex(verticeG, verticeF, verticeE, verticeH, 0, 1, 0, 1, 100, 100); // suelo
	glPopMatrix();
}
void bindear_texturas_jupiter() {
	glBindTexture(GL_TEXTURE_2D, jupiter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);	
}
void spam_jupiter() {
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();
	GLfloat Em[] = { 0.1,0.1,0.2,1.0 };
	GLfloat Am[] = { 0.2,0.2,0.2,1.0 };
	GLfloat Dm[] = { 0.5,0.7,0.6,1.0 };
	GLfloat Sm[] = { 0.8,0.8,0.8,1.0 };
	GLfloat s = 20.0;
	glMaterialfv(GL_FRONT, GL_EMISSION, Em);
	glMaterialfv(GL_FRONT, GL_AMBIENT, Am);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, Dm);
	glMaterialfv(GL_FRONT, GL_SPECULAR, Sm);
	glMaterialf(GL_FRONT, GL_SHININESS, s);
	bindear_texturas_jupiter();
	glTranslatef(40, 40, 40);
	glRotatef(alfa, 0, 0, 1);
	GLUquadric* qobj = gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluQuadricTexture(qobj, true);
	gluQuadricNormals(qobj, GLU_SMOOTH);
	gluSphere(qobj, 15, 20, 20);
	gluDeleteQuadric(qobj);
	glPopMatrix();
	glPopAttrib();
}
void spam_asteroides(int numAsteroides) {
	for (int i = 0; i < numAsteroides; i++) {
		if (i % 2 == 0) {
			alfa_aux = alfa_aux;
			bindear_texturas_asteroide();
		}
		else {
			alfa_aux = -alfa_aux;
			bindear_texturas_asteroide2();
		}
		glPushMatrix();
		glTranslatef(posicionAsteroides[i][0], posicionAsteroides[i][1], posicionAsteroides[i][2]);
		glRotatef(alfa_aux, 1*i/2, 1*i/3, 1);    
		drawAsteroid(2.5);
		glPopMatrix();
	}
}
void spam_asteroides2(int numAsteroides) {
	for (int i = 0; i < numAsteroides; i++) {
		if (i % 2 == 0) {
			alfa_aux = alfa_aux + 1;
		}
		else {
			alfa_aux = -alfa_aux -1.5;
		}
		glPushMatrix();
		glTranslatef(2, i*2, 1.23 * i);
		glRotatef(alfa_aux * 0.1*i, 1 * i / 2, 1 * i / 3, i);
		drawAsteroid(0.3);
		glPopMatrix();
	}
}
void luces_cabina() {
	//luz derecha
	glLightfv(GL_LIGHT7, GL_DIFFUSE, BLANCO);
	glLightf(GL_LIGHT7, GL_SPOT_CUTOFF, 15.0); //radio de la luz
	glLightf(GL_LIGHT7, GL_SPOT_EXPONENT, 5.0); //exponente
	static GLfloat posicionluz7[] = { 2,0,0 ,1 };
	static GLfloat direccionLuz7[] = { 0,-0.3,-1 };
	glLightfv(GL_LIGHT7, GL_POSITION, posicionluz7);
	glLightfv(GL_LIGHT7, GL_SPOT_DIRECTION, direccionLuz7);

	//luz izquierda
	glLightfv(GL_LIGHT6, GL_DIFFUSE, BLANCO);
	glLightf(GL_LIGHT6, GL_SPOT_CUTOFF, 15.0); //radio de la luz
	glLightf(GL_LIGHT6, GL_SPOT_EXPONENT, 5.0); //exponente
	static GLfloat posicionluz6[] = { -2,0,0 ,1 };
	static GLfloat direccionLuz6[] = { 0,-0.3,-1 };
	glLightfv(GL_LIGHT6, GL_POSITION, posicionluz6);
	glLightfv(GL_LIGHT6, GL_SPOT_DIRECTION, direccionLuz6);

	//luz roja
	glLightfv(GL_LIGHT5, GL_DIFFUSE, ROJO);
	glLightf(GL_LIGHT5, GL_SPOT_CUTOFF, 15.0); //radio de la luz
	glLightf(GL_LIGHT5, GL_SPOT_EXPONENT, 5.0); //exponente
	static GLfloat posicionluz5[] = { 0,3,0 ,1 };
	static GLfloat direccionLuz5[] = { 0,-0.3,-1 };
	glLightfv(GL_LIGHT5, GL_POSITION, posicionluz5);
	glLightfv(GL_LIGHT5, GL_SPOT_DIRECTION, direccionLuz5);

	//luz derecha antiniebla
	glLightfv(GL_LIGHT4, GL_DIFFUSE, AZUL);
	glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, 25.0); //radio de la luz
	glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 3.0); //exponente
	static GLfloat posicionluz4[] = { 3,1,0 ,1 };
	static GLfloat direccionLuz4[] = { 0,-0.3,-1 };
	glLightfv(GL_LIGHT4, GL_POSITION, posicionluz4);
	glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, direccionLuz4);

	//luz izquierda antiniebla
	glLightfv(GL_LIGHT3, GL_DIFFUSE, AZUL);
	glLightf(GL_LIGHT3, GL_SPOT_CUTOFF, 25.0); //radio de la luz
	glLightf(GL_LIGHT3, GL_SPOT_EXPONENT, 3.0); //exponente
	static GLfloat posicionluz3[] = { -3,1,0 ,1 };
	static GLfloat direccionLuz3[] = { 0,-0.3,-1 };
	glLightfv(GL_LIGHT3, GL_POSITION, posicionluz3);
	glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, direccionLuz3);
}
void display()
// Funcion de atencion al dibujo
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//************************
	//todas las luces
	luces_cabina();
	//***********************


	glPushMatrix();
	camara_ajustes();
	glPopMatrix();
	gluLookAt(camara_pos_act[0], camara_pos_act[1], camara_pos_act[2], objetivo[0], objetivo[1], objetivo[2], altura_act[0], altura_act[1], altura_act[2]);
	
	//Suelo 
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	draw_suelo();
	glPopAttrib();

	//hangar
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	draw_hangar();
	glPopAttrib();

	//jupiter
	spam_jupiter();

	//asteroides con movimiento aleatorio
	glPushMatrix();
	spam_asteroides(numAsteroides);
	//spam_asteroides2(numAsteroides);
	glPopMatrix();
	
	glPushMatrix();
	glTranslatef(camara_pos_act[0], camara_pos_act[1], camara_pos_act[2]);
	draw_fondo_estelar();
	glPopMatrix();

	//cabina
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);

	GLfloat difuso[] = { 0.8,0.7,0.2,1 };
	glMaterialfv(GL_FRONT, GL_DIFFUSE, difuso);
	GLfloat especular[] = { 0.6,0.6,0.5,1 };
	glMaterialfv(GL_FRONT, GL_SPECULAR, especular);
	glMaterialf(GL_FRONT, GL_SHININESS, 100);

	glBindTexture(GL_TEXTURE_2D, cabina);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	if (cabina_se_vea_bool > 0) {
		distancia_cabina_cara = 2.0f;

	}
	else {
		distancia_cabina_cara = -100.0f;

	}



	Vec3 local_vertice0 = Vec3(-2.25f, -2.5f, -distancia_cabina_cara); 
	Vec3 local_vertice1 = Vec3(-2.25f, 2.5f, -distancia_cabina_cara); 
	Vec3 local_vertice2 = Vec3(2.25f, 2.5f, -distancia_cabina_cara);
	Vec3 local_vertice3 = Vec3(2.25f, -2.5f, -distancia_cabina_cara);

	Vec3 global_vertice0 = camara.local2global(local_vertice0); 
	Vec3 global_vertice1 = camara.local2global(local_vertice1); 
	Vec3 global_vertice2 = camara.local2global(local_vertice2);
	Vec3 global_vertice3 = camara.local2global(local_vertice3);

	quadtex(global_vertice3, global_vertice0, global_vertice1, global_vertice2); 

	glPopAttrib();
	glPopMatrix();
	glutSwapBuffers();

}
void reshape(GLint w, GLint h)
// Funcion de atencion al redimensionamiento
{
	ancho_de_ventana = w;
	altura_de_ventana = h;
	x_centro = ancho_de_ventana / 2;
	y_centro = altura_de_ventana / 2;
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	float razon = (float)w / h;

	// CAMARA PERSPECTIVA -> OBLIGATORIO
	gluPerspective(60, razon, 0.1 , 300);
}
void update()
{
	static const float vueltasxsegundo = 0.1;
	static const float SubidasBajadas = 0.4;
	static int hora_anterior = glutGet(GLUT_ELAPSED_TIME);
	int hora_actual = glutGet(GLUT_ELAPSED_TIME);
	float tiempo_transcurrido = (hora_actual - hora_anterior) / 1000.0f;

	alfa += vueltasxsegundo * 360 /*grados por vuelta*/ * tiempo_transcurrido;
	alfa_aux += vueltasxsegundo * 360 /*grados por vuelta*/ * tiempo_transcurrido;

	cont = cont + 1;

	hora_anterior = hora_actual;

	//beta
	if ((direccion == -1)) {
		beta -= 0.01;
	}
	if ((direccion == 1)) {
		beta += 0.01;
	}

	if ((beta >= -1.00) or (beta <= -1.50)) {
		direccion = direccion * -1;
	}

	//sigma
	if ((direccion2 == -1)) {
		sigma -= 0.02;
	}

	if ((direccion2 == 1)) {
		sigma += 0.02;
	}
	if ((sigma >= 8) or (sigma <= 1)) {
		direccion2 = direccion2 * -1;
	}
	glutPostRedisplay();
}
void onMotion(int x, int z)
{
	float x1 = x - (ancho_de_ventana / 2);
	float z1 = z - (altura_de_ventana / 2);

	camara.rotar(-rad(x1 / 25), camara.getv());
	camara.rotar(-rad(z1 / 25), camara.getu());

	glutWarpPointer(x_centro, y_centro);
}
void onKey(unsigned char tecla, int x, int y)
// Funcion de atencion al teclado
{
	switch (tecla) {
	case 'a': // aumentar velocidad
		if (vel_act < 0.3) {
			vel_act += 0.05;
		}

		break;
	case 'f':// frenar
		vel_act -= 0.05;
		break;

	case 'c': // para ver la cabina o no
		cabina_se_vea_bool = cabina_se_vea_bool *- 1; 
		break;

	case 'm': // boton para poner y quitar la musica
		if (musica) {
			mciSendString(o, NULL, 0, NULL);
			musica = false;
		}
		else {
			mciSendString(p, NULL, 0, NULL);
			musica = true;
		}
		break;
	case 'l': // boton para poner y quitar las luces focales blancas basicas
		if(luces_activadas){
			luces_activadas = false;
			glDisable(GL_LIGHT6);
			glDisable(GL_LIGHT7);
		}
		else {
			luces_activadas = true;
			glEnable(GL_LIGHT6);
			glEnable(GL_LIGHT7);
		}
		break;
	case 'r': // boton para poner y quitar la luz roja minera
		if (luz_roja_activada) {
			luz_roja_activada = false;
			glDisable(GL_LIGHT5);
		}
		else {
			luz_roja_activada = true;
			glEnable(GL_LIGHT5);
		}
		break;
	case 'p': // boton para poner y quitar las luces antinieblas
		if (luces_antinieblas_activadas) {
			luces_antinieblas_activadas = false;
			glDisable(GL_LIGHT4);
			glDisable(GL_LIGHT3);
		}
		else {
			luces_antinieblas_activadas = true;
			glEnable(GL_LIGHT4);
			glEnable(GL_LIGHT3);
		}
		break;
	case 's': //boton hipersalto
		camara.seto(camara.geto()- camara.getw() * 10);
		break;
	case 27: // Salir de la aplicacion
		exit(0);
	}
	glutPostRedisplay();

}
void onTimer(int valor)
// Funcion de atencion al timer periodico
{
	static int hora_anterior = 0;
	int hora_actual = glutGet(GLUT_ELAPSED_TIME);
	float tiempo_transcurrido = (hora_actual - hora_anterior) / 1000.0f;

	Vec3 direccionMovimiento = (camara.getw()) * -1;
	if (vel_act > 0) {
		camara.seto(camara.geto() + ((camara.getw()) * -1 * (vel_act)));
	}
	for (int i = 0; i < numAsteroides; i++) {
		posicionAsteroides[i][0] += velocidad_Asteroides[i][0] * tiempo_transcurrido;
		posicionAsteroides[i][1] += velocidad_Asteroides[i][1] * tiempo_transcurrido;
		posicionAsteroides[i][2] += velocidad_Asteroides[i][2] * tiempo_transcurrido;
	}
	update();

	hora_anterior = hora_actual;
	glutTimerFunc(1000 / FPS, onTimer, FPS); 
	glutPostRedisplay(); 

}
void init()
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GREATER, 0.1f);
	glDepthMask(GL_TRUE);

	glutSetCursor(GLUT_CURSOR_NONE);

	//LUZ UNIVERSAL
	GLfloat Al0[] = { 0.3,0.3,0.3,1.0 }; // Color ambiental de la luz
	GLfloat Dl0[] = { 0.3,0.3,0.3,1.0 }; // Color difuso de la luz
	GLfloat Sl0[] = { 0.3,0.3,0.3,1.0 }; // Color especular de la luz
	glLightfv(GL_LIGHT0, GL_AMBIENT, Al0); // Caracteristicas de LIGHT0
	glLightfv(GL_LIGHT0, GL_DIFFUSE, Dl0);
	glLightfv(GL_LIGHT0, GL_SPECULAR, Sl0);
	GLfloat posicion[] = { 0,10,0,0 };
	glLightfv(GL_LIGHT0, GL_POSITION, posicion);
	glEnable(GL_LIGHT0);
	
	// cargamos las texturas.
	cargar_Texturas();

	//musica
	mciSendString(u, NULL, 0, NULL);
	mciSendString(i, NULL, 0, NULL);
	mciSendString(o, NULL, 0, NULL);

	glEnable(GL_DEPTH_TEST); // requisito visibilidad
	glEnable(GL_LIGHTING);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_TEXTURE_2D);
	camara = Sistema3d({ 1,0,0 }, { 0,0,1 }, { 0,-1,0 }, { 0,0,z_global }); 
	glutWarpPointer(x_centro, y_centro);

	//matriz de posiciones para los asteroides
	for (int i = 0; i < numAsteroides; i++) {
		posicionAsteroides[i][0] = random(-dim_Espacio / 4, dim_Espacio / 4);
		posicionAsteroides[i][1] = random(-dim_Espacio / 4, dim_Espacio / 4);
		posicionAsteroides[i][2] = random(-dim_Espacio / 4, dim_Espacio / 4);
		
		velocidad_Asteroides[i][0] = random(-3, 3);
		velocidad_Asteroides[i][1] = random(-3, 3);
		velocidad_Asteroides[i][2] = random(-3, 3);
	}
}
int main(int argc, char** argv)
// Programa principal
{
	glutInit(&argc, argv); 
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); 
	glutInitWindowSize(1380, 820); 
	glutCreateWindow(PROYECTO); 
	glutDisplayFunc(display); 
	glutReshapeFunc(reshape);
	glutPassiveMotionFunc(onMotion); 
	glutTimerFunc(1000 / FPS, onTimer, FPS); 
	glutKeyboardFunc(onKey); 

	init(); //inicializaci�n -> init
	glutMainLoop(); //marcha del programa
	FreeImage_DeInitialise();
	return 0;
}